# Ultimate Tic Tac Toe Spring 2014

Welcome to the README for Ultimate Tic Tac Toe Project!

### General Information

#### How to Play the Game
There are 2 player, with player 1 represented by 'X' and player 2 represented
by 'O'. 

An Ultimate tic-tax-toe game is a game made up of 9 small tic-tax-toe games
combined to form one large tic-tax-toe game. To make 1 mark on the large 
tic-tax-toe board, you will need to win at a small game of tic-tax-toe.

#### Original Game
Click here to see original rules: http://mck-.github.io/T3/#/howto ; however
unlike the original game, when you make a move to claim the center square
the next move does not have to be in the same small tic-tax-toe board.

### Build
Run the following in command line:
```
javac UltimateTicTacToe.java
java UltimateTicTacToe
```